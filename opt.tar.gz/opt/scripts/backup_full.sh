#!/bin/bash

# Mostrar ayuda
show_help() {
	echo -e "Uso: $0 [-h] origen destino \n "
	echo "Argumentos:"
	echo "  origen   Directorio de origen para el backup"
	echo -e "  destino  Directorio de destino donde se guardara el backup \n "
	echo "Opciones:"
	echo "  -h	Muestra esta ayuda."
	exit
}

# Validar argumentos
if [[ "$1" == "-h" ]]; then
	show_help
fi

if [[ $# -ne 2 ]]; then
	echo -e "Error: Se requieren exactamente 2 argumentos (origen y destino)\n"
	show_help
fi

ORIGEN="$1"
DESTINO="$2"

# Validar que los dfirectorios existen
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: El directorio de origen $ORIGEN no existe"
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error: EL directorio de destino $DESTINO no existe"
	exit 1
fi

#Crear nombre de archivo de backup
FECHA=$(date +%Y%m%d)
NOMBRE_BACKUP=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz

# Realizar el backup
echo -e "Iniciando backup de $ORIGEN a $DESTINO ...\n"

tar czf "$DESTINO/$NOMBRE_BACKUP" -C "$ORIGEN" .

if [[ $? -eq 0 ]]; then
	echo "Backup completado exitosamente: $NOMBRE_BACKUP"
else
	echo "Error: Fallo la creacion del backup"
	exit 1
fi


